export class Plan {
    plantName: String;
    plantMachine: String;
    fillVol:number;
    fillVol3:number;
    closureTorque:boolean;
    closureJumpTest:boolean;
    closurePilferBand:boolean;
    closureSecureSeal:boolean;
    stressCrackTest:boolean;
    dropTest:boolean;
    packageAppearance:String;
    dateCodingRubTest:String;
}
