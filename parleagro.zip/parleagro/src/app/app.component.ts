import { Component } from '@angular/core';
import { DataserviceService } from './dataservice.service';

interface Plants {
  value: string;
  viewValue: string;
}

interface Machines {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'parleagro';
  Plan
  fillVol:String;
  fillVol3:String;

  constructor(private dataService: DataserviceService) { }
  
  counter(i: number) {
    return new Array(i);
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  savePlan() {
    console.log("Clicked");
    this.dataService.savePlan().subscribe((data: any[])=>{
      console.log(data);
    })
  }

  plant: Plants[] = [
    {value: 'plant-0', viewValue: 'Silvasa'},
    {value: 'plant-1', viewValue: 'Nagpur'},
    {value: 'plant-2', viewValue: 'Jodhpur'}
  ];

  machine: Machines[] = [
    {value: 'machine-0', viewValue: 'Machine 0'},
    {value: 'machine-1', viewValue: 'Machine 1'},
    {value: 'machine-2', viewValue: 'Machine 2'}
  ];

}
