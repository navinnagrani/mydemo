import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    Authorization: 'my-auth-token'
  })
};

@Injectable({
  providedIn: 'root'
})



export class DataserviceService {
  private REST_API_SERVER = "http://localhost:8080";
  constructor(private httpClient: HttpClient) { }
  
  public savePlan(){
    return this.httpClient.post(this.REST_API_SERVER+'/api/saveplan',httpOptions);
  }
}
