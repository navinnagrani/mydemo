package com.parle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParleAgroApplicationTests {

	@Test
	void contextLoads() {
	}

}
